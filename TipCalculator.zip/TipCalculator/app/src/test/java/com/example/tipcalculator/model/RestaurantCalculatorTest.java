package com.example.tipcalculator.model;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import static junit.framework.TestCase.assertEquals;

@RunWith(JUnit4.class)
public class RestaurantCalculatorTest {

	private RestaurantCalculator calculator;

	@Before
	public void setup(){
		calculator = new RestaurantCalculator();
	}

	@Test
	public void testCalculator(){
		double checkInput = 10.00;
		int tipPct = 25;

		TipCalculation tipCalculation = new TipCalculation();
		tipCalculation.setCheckAmount(checkInput);
		tipCalculation.setTipPercentage(25);
		tipCalculation.setTipAmount(2.50);
		tipCalculation.setGrandTotal(12.50);

		assertEquals(tipCalculation, calculator.calculateTip(checkInput, tipPct));


	}
}
