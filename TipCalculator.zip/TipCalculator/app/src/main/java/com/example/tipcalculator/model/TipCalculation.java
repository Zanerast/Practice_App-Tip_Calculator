package com.example.tipcalculator.model;

public class TipCalculation {

	private double checkAmount = 0.0;
	private int tipPercentage = 0;
	private double tipAmount = 0.0;
	private double grandTotal = 0.0;

	@Override
	public boolean equals(@androidx.annotation.Nullable Object obj) {
		return super.equals(obj);
	}

	public double getCheckAmount() {
		return checkAmount;
	}

	public void setCheckAmount(double checkAmount) {
		this.checkAmount = checkAmount;
	}

	public int getTipPercentage() {
		return tipPercentage;
	}

	public void setTipPercentage(int tipPercentage) {
		this.tipPercentage = tipPercentage;
	}

	public double getTipAmount() {
		return tipAmount;
	}

	public void setTipAmount(double tipAmount) {
		this.tipAmount = tipAmount;
	}

	public double getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(double grandTotal) {
		this.grandTotal = grandTotal;
	}
}
